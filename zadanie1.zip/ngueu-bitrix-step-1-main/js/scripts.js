"use strict";

document.addEventListener('DOMContentLoaded', () => {
    console.log('Working...');
});